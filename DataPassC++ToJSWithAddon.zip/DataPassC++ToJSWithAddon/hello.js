var addon = require('bindings')('hello');

// console.log(addon);
// addon.simple();

function foo() {
        console.log("woohoo!");
}

addon.setCallback(foo);
addon.call(() => console.log("call!")) ;
addon.callThis(() => console.log("this too!"));